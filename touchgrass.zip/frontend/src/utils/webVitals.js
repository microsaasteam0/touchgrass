import React from 'react';
  
  const WebVitals = () =>  {
	return (
	  <div>
	  </div>
	);
  }
  
  export default WebVitals;
  export function reportWebVitals(onPerfEntry) {
  if (onPerfEntry && typeof onPerfEntry === 'function') {
    onPerfEntry({});
  }
}
