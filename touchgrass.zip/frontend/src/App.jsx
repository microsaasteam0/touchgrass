import React, { useState, useEffect, Suspense } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css'

// Lazy load pages for better performance
const Home = React.lazy(() => import('./pages/Home'));
const Dashboard = React.lazy(() => import('./pages/Dashboard'));
const Verify = React.lazy(() => import('./pages/Verify'));
const Leaderboard = React.lazy(() => import('./pages/Leaderboard'));
const Profile = React.lazy(() => import('./pages/profile'));
const Subscription = React.lazy(() => import('./pages/Subscription'));
const Auth = React.lazy(() => import('./pages/Auth'));
const ChatPage = React.lazy(() => import('./pages/ChatPage'));
const Challenges = React.lazy(() => import('./pages/Challenges'));
const Settings = React.lazy(() => import('./pages/Settings'));
const NotFound = React.lazy(() => import('./pages/NotFound'));
const PaymentPage = React.lazy(() => import('./pages/Payment'));
const PaymentSuccess = React.lazy(() => import('./pages/PaymentSuccess'));
// Remove or comment out DodoCheckout and PaymentCancel since they don't exist
// const DodoCheckout = React.lazy(() => import('./pages/DodoCheckout'));
// const PaymentCancel = React.lazy(() => import('./pages/PaymentCancel'));

// Components
import Navbar from './components/layout/Navbar';
import Footer from './components/layout/Footer';
import LoadingScreen from './components/ui/LoadingScreen';
import Confetti from './components/ui/Confetti';

// Context & State
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { StreakProvider } from './contexts/StreakContext';
import { ChatProvider } from './contexts/ChatContext';
import { NotificationProvider } from './contexts/NotificationContext';

// CSS imports
import './global.css';
import './styles/animations.css';
import './styles/themes.css';

// Route transition wrapper
const RouteTransition = ({ children, animation = 'fade' }) => {
  const location = useLocation();
  
  const animations = {
    fade: {
      initial: { opacity: 0 },
      animate: { opacity: 1 },
      exit: { opacity: 0 },
      transition: { duration: 0.3 }
    },
    slideUp: {
      initial: { opacity: 0, y: 20 },
      animate: { opacity: 1, y: 0 },
      exit: { opacity: 0, y: -20 },
      transition: { duration: 0.3 }
    },
    slideIn: {
      initial: { opacity: 0, x: -20 },
      animate: { opacity: 1, x: 0 },
      exit: { opacity: 0, x: 20 },
      transition: { duration: 0.3 }
    },
    scale: {
      initial: { opacity: 0, scale: 0.95 },
      animate: { opacity: 1, scale: 1 },
      exit: { opacity: 0, scale: 0.95 },
      transition: { duration: 0.3 }
    }
  };

  const selectedAnimation = animations[animation] || animations.fade;

  return (
    <motion.div
      key={location.pathname}
      initial={selectedAnimation.initial}
      animate={selectedAnimation.animate}
      exit={selectedAnimation.exit}
      transition={selectedAnimation.transition}
      style={{ width: '100%', height: '100%' }}
    >
      {children}
    </motion.div>
  );
};

// Protected Route Component
const ProtectedRoute = ({ children, requireAuth = true }) => {
  const { isAuthenticated, loading } = useAuth();
  
  if (loading) {
    return <LoadingScreen />;
  }
  
  if (requireAuth && !isAuthenticated) {
    return <Navigate to="/auth" />;
  }
  
  return children;
};

// Public Route Component
const PublicRoute = ({ children }) => {
  const { isAuthenticated, loading } = useAuth();
  
  if (loading) {
    return <LoadingScreen />;
  }
  
  const isAuthPage = window.location.pathname === '/auth';
  if (isAuthenticated && isAuthPage) {
    return <Navigate to="/dashboard" />;
  }
  
  return children;
};

// Main App Content
function AppContent() {
  const { user, loading } = useAuth();
  const [showConfetti, setShowConfetti] = useState(false);
  const [theme, setTheme] = useState('dark');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const location = useLocation();

  // Handle confetti for achievements
  useEffect(() => {
    const handleAchievement = (event) => {
      setShowConfetti(true);
      setTimeout(() => setShowConfetti(false), 5000);
    };

    window.addEventListener('achievement-unlocked', handleAchievement);
    return () => window.removeEventListener('achievement-unlocked', handleAchievement);
  }, []);

  // Handle theme
  useEffect(() => {
    const savedTheme = localStorage.getItem('theme') || 'dark';
    setTheme(savedTheme);
    document.documentElement.setAttribute('data-theme', savedTheme);
  }, []);

  const toggleTheme = () => {
    const newTheme = theme === 'dark' ? 'light' : 'dark';
    setTheme(newTheme);
    localStorage.setItem('theme', newTheme);
    document.documentElement.setAttribute('data-theme', newTheme);
  };

  // App loading screen
  if (loading) {
    return <LoadingScreen fullScreen />;
  }

  return (
    <div className={`app-container theme-${theme}`}>
      {/* Confetti Effect */}
      {showConfetti && <Confetti />}

      {/* Global Navigation */}
      <Navbar 
        isAuthenticated={!!user}
        user={user}
        theme={theme}
        toggleTheme={toggleTheme}
        isMobileMenuOpen={isMobileMenuOpen}
        setIsMobileMenuOpen={setIsMobileMenuOpen}
      />

      {/* Main Content */}
      <main className="main-content">
        <AnimatePresence mode="wait">
          <Suspense fallback={<LoadingScreen />}>
            <Routes location={location} key={location.pathname}>
              {/* Public Routes */}
              <Route 
                path="/" 
                element={
                  <RouteTransition animation="fade">
                    <Home />
                  </RouteTransition>
                } 
              />

              <Route 
                path="/auth" 
                element={
                  <PublicRoute>
                    <RouteTransition animation="slideUp">
                      <Auth />
                    </RouteTransition>
                  </PublicRoute>
                } 
              />

              <Route 
                path="/leaderboard" 
                element={
                  <RouteTransition animation="fade">
                    <Leaderboard />
                  </RouteTransition>
                } 
              />

              {/* Protected Routes */}
              <Route 
                path="/dashboard" 
                element={
                  <ProtectedRoute>
                    <RouteTransition animation="scale">
                      <Dashboard />
                    </RouteTransition>
                  </ProtectedRoute>
                } 
              />

              <Route 
                path="/verify" 
                element={
                  <ProtectedRoute>
                    <RouteTransition animation="slideIn">
                      <Verify />
                    </RouteTransition>
                  </ProtectedRoute>
                } 
              />

              <Route 
                path="/profile" 
                element={
                  <ProtectedRoute>
                    <RouteTransition animation="slideUp">
                      <Profile />
                    </RouteTransition>
                  </ProtectedRoute>
                } 
              />

              <Route 
                path="/profile/:username" 
                element={
                  <ProtectedRoute>
                    <RouteTransition animation="slideUp">
                      <Profile />
                    </RouteTransition>
                  </ProtectedRoute>
                } 
              />

              <Route 
                path="/subscription" 
                element={
                  <ProtectedRoute>
                    <RouteTransition animation="scale">
                      <Subscription />
                    </RouteTransition>
                  </ProtectedRoute>
                } 
              />

              <Route 
                path="/chat" 
                element={
                  <ProtectedRoute>
                    <RouteTransition animation="fade">
                      <ChatPage />
                    </RouteTransition>
                  </ProtectedRoute>
                } 
              />

              <Route 
                path="/challenges" 
                element={
                  <ProtectedRoute>
                    <RouteTransition animation="slideIn">
                      <Challenges />
                    </RouteTransition>
                  </ProtectedRoute>
                } 
              />

              <Route 
                path="/settings" 
                element={
                  <ProtectedRoute>
                    <RouteTransition animation="scale">
                      <Settings />
                    </RouteTransition>
                  </ProtectedRoute>
                } 
              />

              {/* Payment Routes */}
              <Route 
                path="/payment" 
                element={
                  <ProtectedRoute>
                    <RouteTransition animation="fade">
                      <PaymentPage />
                    </RouteTransition>
                  </ProtectedRoute>
                } 
              />

              {/* Comment out or remove DodoCheckout route since component doesn't exist */}
              {/* <Route 
                path="/payment/checkout/:productType" 
                element={
                  <ProtectedRoute>
                    <RouteTransition animation="fade">
                      <DodoCheckout />
                    </RouteTransition>
                  </ProtectedRoute>
                } 
              /> */}

              <Route 
                path="/payment/success" 
                element={
                  <RouteTransition animation="fade">
                    <PaymentSuccess />
                  </RouteTransition>
                } 
              />

              {/* Comment out or remove PaymentCancel route since component doesn't exist */}
              {/* <Route 
                path="/payment/cancel" 
                element={
                  <RouteTransition animation="fade">
                    <PaymentCancel />
                  </RouteTransition>
                } 
              /> */}

              {/* 404 Route */}
              <Route 
                path="*" 
                element={
                  <RouteTransition animation="fade">
                    <NotFound />
                  </RouteTransition>
                } 
              />
            </Routes>
          </Suspense>
        </AnimatePresence>
      </main>

      {/* Global Footer */}
      <Footer theme={theme} />

      {/* Toast Notifications */}
      <ToastContainer
        position="top-right"
        autoClose={5000}
        hideProgressBar={false}
        newestOnTop
        closeOnClick
        rtl={false}
        pauseOnFocusLoss
        draggable
        pauseOnHover
        theme="dark"
        toastClassName="custom-toast"
        bodyClassName="toast-body"
        progressClassName="toast-progress"
      />

      {/* Global Modals Portal */}
      <div id="modal-root"></div>

      {/* Floating Action Button for Mobile */}
      {user && (
        <motion.button
          className="floating-action-button"
          initial={{ scale: 0, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          onClick={() => window.location.href = '/verify'}
        >
          <span className="fab-icon">🌱</span>
          <span className="fab-pulse"></span>
        </motion.button>
      )}
    </div>
  );
}

// Main App Component with Providers
function App() {
  return (
    <AuthProvider>
      <StreakProvider>
        <ChatProvider>
          <NotificationProvider>
            <Router>
              <AppContent />
            </Router>
          </NotificationProvider>
        </ChatProvider>
      </StreakProvider>
    </AuthProvider>
  );
}

export default App;